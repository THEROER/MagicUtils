package dev.ua.theroer.magicutils.platform.velocity;

import dev.ua.theroer.magicutils.platform.PlatformLogger;
import org.slf4j.Logger;

/**
 * SLF4J-backed platform logger for Velocity runtime.
 */
public final class VelocityPlatformLogger implements PlatformLogger {
    private final Logger delegate;

    /**
     * Creates a logger wrapper.
     *
     * @param delegate slf4j logger
     */
    public VelocityPlatformLogger(Logger delegate) {
        this.delegate = delegate;
    }

    @Override
    public void info(String message) {
        delegate.info(message);
    }

    @Override
    public void warn(String message) {
        delegate.warn(message);
    }

    @Override
    public void warn(String message, Throwable throwable) {
        delegate.warn(message, throwable);
    }

    @Override
    public void error(String message) {
        delegate.error(message);
    }

    @Override
    public void error(String message, Throwable throwable) {
        delegate.error(message, throwable);
    }

    @Override
    public void debug(String message) {
        delegate.debug(message);
    }

    @Override
    public boolean isDebugEnabled() {
        return delegate.isDebugEnabled();
    }

    @Override
    public boolean isTraceEnabled() {
        return delegate.isTraceEnabled();
    }
}
