package dev.ua.theroer.magicutils.lang;

import java.util.LinkedHashMap;
import java.util.Map;

final class LanguageDefaults {

    static final String DEFAULT_NAME = "English";
    static final String DEFAULT_CODE = "en";
    static final String DEFAULT_AUTHOR = "MagicUtils Team";
    static final String DEFAULT_VERSION = "1.0";

    private LanguageDefaults() {
    }

    static Map<String, String> englishCommands() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("no_permission", "&cYou don't have permission to execute this command!");
        map.put("execution_error", "&cAn error occurred while executing the command");
        map.put("executed", "&aCommand executed successfully");
        map.put("specify_subcommand", "&eSpecify a subcommand: &f{subcommands}");
        map.put("unknown_subcommand", "&cUnknown subcommand: &f{subcommand}");
        map.put("invalid_arguments", "&cInvalid command arguments. Usage: &7{usage}");
        map.put("not_found", "&cCommand not found");
        map.put("internal_error", "&cAn internal error occurred while executing the command");
        map.put("help.command_description", "Shows available commands and usages");
        map.put("help.subcommand_description", "Shows available commands and usages");
        map.put("help.sender_unavailable", "Sender unavailable");
        map.put("help.unavailable", "Help unavailable (command manager not ready)");
        map.put("help.command_not_found", "Command not found.");
        map.put("help.title", "Help");
        map.put("help.available_commands", "Available commands:");
        map.put("help.no_commands_found", "No commands found.");
        map.put("help.label.command", "Command:");
        map.put("help.label.description", "Description:");
        map.put("help.label.aliases", "Aliases:");
        map.put("help.label.subcommands", "Subcommands:");
        map.put("help.label.arguments", "Arguments:");
        map.put("help.optional", "(Optional)");
        map.put("help.default_value", "(Default: {value})");
        map.put("help.values", "(Values: {values})");
        map.put("help.page_label", "Page");
        map.put("help.nav.previous", "Previous page");
        map.put("help.nav.next", "Next page");
        map.put("help.query_prefix", "Showing search results for query:");
        map.put("help.no_description", "No description");
        map.put("help.hover.show", "Click to show help for this command");
        map.put("help.aliases_inline", "(aliases: {aliases})");
        map.put("help.argument_permission", "Argument {argument} for /{command}{subcommandSuffix}");
        map.put("help.usage_or", "OR");
        return map;
    }

    static Map<String, String> englishSettings() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("language_not_initialized", "&cLanguage manager not initialized!");
        map.put("invalid_arguments",
                "&cInvalid arguments. First argument must be a language name when using 3 arguments.");
        map.put("current_language", "&aCurrent language: &f{language}");
        map.put("available_languages", "&aAvailable languages: &f{languages}");
        map.put("language_not_found", "&cLanguage '&f{language}&c' not found!");
        map.put("key_not_found", "&cKey '&f{key}&c' not found in language '&f{language}&c'");
        map.put("key_value", "&aLanguage: &f{language}\n&aKey: &f{key}\n&aValue: &f{value}");
        map.put("key_set", "&aSet key '&f{key}&a' to '&f{value}&a' in language '&f{language}&a'");
        return map;
    }

    static Map<String, String> englishReload() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("all_commands", "&aAll commands reloaded!");
        map.put("command", "&aCommand &f{command} &areloaded!");
        map.put("all_sections", "&aAll sections reloaded!");
        map.put("section", "&aSection &f{section} &areloaded!");
        map.put("global_settings", "&aGlobal settings reloaded!");
        map.put("global_setting", "&aGlobal setting &f{setting} &areloaded!");
        return map;
    }

    static Map<String, String> englishSystem() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("loaded_language", "Loaded language: {language}");
        map.put("failed_load_language", "Failed to load language: {language}");
        map.put("failed_save_messages", "Failed to save custom messages for language: {language}");
        map.put("created_default_config", "Created default config: {file}");
        map.put("section_not_reloadable", "Section not reloadable: {section}");
        map.put("command_registered", "Successfully registered command: {command} with aliases: {aliases}");
        map.put("command_usage", "Command usage: {usage}");
        map.put("subcommand_usages", "Subcommand usages:");
        map.put("alias_registered", "Successfully registered alias: {alias} for command: {command}");
        map.put("alias_usage", "Alias usage: {usage}");
        map.put("generated_permissions", "Generated permissions for {command}: {permissions}");
        map.put("unregistered_command", "Unregistered command: {command}");
        return map;
    }

    static Map<String, String> englishErrors() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("message_not_set", "Message must be set before sending");
        map.put("failed_get_commandmap", "Failed to get CommandMap");
        map.put("registry_not_initialized",
                "CommandRegistry not initialized! Call initialize() first.");
        map.put("commandmap_not_available", "CommandMap not available!");
        map.put("missing_commandinfo", "Command class must have @CommandInfo annotation: {class}");
        map.put("missing_configfile", "Class {class} must have @ConfigFile annotation");
        map.put("required_config_missing", "Missing required config value: {path}");
        return map;
    }

    static Map<String, String> englishTranslations() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        putPrefixed(map, "magicutils.commands", englishCommands());
        putPrefixed(map, "magicutils.settings", englishSettings());
        putPrefixed(map, "magicutils.reload", englishReload());
        putPrefixed(map, "magicutils.system", englishSystem());
        putPrefixed(map, "magicutils.errors", englishErrors());
        return map;
    }

    private static void putPrefixed(Map<String, String> target, String prefix, Map<String, String> values) {
        for (Map.Entry<String, String> entry : values.entrySet()) {
            target.put(prefix + "." + entry.getKey(), entry.getValue());
        }
    }

    static Map<String, Map<String, String>> localizedSections(String languageCode) {
        Map<String, Map<String, String>> translations = new LinkedHashMap<>();
        switch (languageCode) {
            case "en":
                translations.put("language", englishMetadata());
                translations.put("magicutils.commands", englishCommands());
                translations.put("magicutils.settings", englishSettings());
                translations.put("magicutils.reload", englishReload());
                translations.put("magicutils.system", englishSystem());
                translations.put("magicutils.errors", englishErrors());
                break;
            case "uk":
                translations.put("language", ukrainianMetadata());
                translations.put("magicutils.commands", ukrainianCommands());
                translations.put("magicutils.settings", ukrainianSettings());
                translations.put("magicutils.reload", ukrainianReload());
                translations.put("magicutils.system", ukrainianSystem());
                translations.put("magicutils.errors", ukrainianErrors());
                break;
            default:
                break;
        }
        return translations;
    }

    private static Map<String, String> englishMetadata() {
        LinkedHashMap<String, String> metadata = new LinkedHashMap<>();
        metadata.put("name", DEFAULT_NAME);
        metadata.put("code", DEFAULT_CODE);
        metadata.put("author", DEFAULT_AUTHOR);
        metadata.put("version", DEFAULT_VERSION);
        return metadata;
    }

    private static Map<String, String> ukrainianMetadata() {
        LinkedHashMap<String, String> metadata = new LinkedHashMap<>();
        metadata.put("name", "Українська");
        metadata.put("code", "uk");
        metadata.put("author", DEFAULT_AUTHOR);
        metadata.put("version", DEFAULT_VERSION);
        return metadata;
    }

    private static Map<String, String> ukrainianCommands() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("no_permission", "&cУ вас немає прав для виконання цієї команди!");
        map.put("execution_error", "&cПід час виконання команди сталася помилка");
        map.put("executed", "&aКоманду виконано успішно");
        map.put("specify_subcommand", "&eВкажіть підкоманду: &f{subcommands}");
        map.put("unknown_subcommand", "&cНевідома підкоманда: &f{subcommand}");
        map.put("invalid_arguments", "&cНеправильні аргументи. Використання: &7{usage}");
        map.put("not_found", "&cКоманду не знайдено");
        map.put("internal_error", "&cСталася внутрішня помилка під час виконання команди");
        map.put("help.command_description", "Показує доступні команди та їх використання");
        map.put("help.subcommand_description", "Показує доступні команди та їх використання");
        map.put("help.sender_unavailable", "Відправник недоступний");
        map.put("help.unavailable", "Довідка недоступна (менеджер команд ще не готовий)");
        map.put("help.command_not_found", "Команду не знайдено.");
        map.put("help.title", "Довідка");
        map.put("help.available_commands", "Доступні команди:");
        map.put("help.no_commands_found", "Команд не знайдено.");
        map.put("help.label.command", "Команда:");
        map.put("help.label.description", "Опис:");
        map.put("help.label.aliases", "Аліаси:");
        map.put("help.label.subcommands", "Підкоманди:");
        map.put("help.label.arguments", "Аргументи:");
        map.put("help.optional", "(Необов'язково)");
        map.put("help.default_value", "(Типове значення: {value})");
        map.put("help.values", "(Значення: {values})");
        map.put("help.page_label", "Сторінка");
        map.put("help.nav.previous", "Попередня сторінка");
        map.put("help.nav.next", "Наступна сторінка");
        map.put("help.query_prefix", "Показано результати пошуку за запитом:");
        map.put("help.no_description", "Опис відсутній");
        map.put("help.hover.show", "Натисніть, щоб показати довідку для цієї команди");
        map.put("help.aliases_inline", "(аліаси: {aliases})");
        map.put("help.argument_permission", "Аргумент {argument} для /{command}{subcommandSuffix}");
        map.put("help.usage_or", "АБО");
        return map;
    }

    private static Map<String, String> ukrainianSettings() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("language_not_initialized", "&cМенеджер мов не ініціалізований!");
        map.put("invalid_arguments",
                "&cНеправильні аргументи. Перший аргумент повинен бути назвою мови при використанні 3 аргументів.");
        map.put("current_language", "&aПоточна мова: &f{language}");
        map.put("available_languages", "&aДоступні мови: &f{languages}");
        map.put("language_not_found", "&cМова '&f{language}&c' не знайдена!");
        map.put("key_not_found", "&cКлюч '&f{key}&c' не знайдений в мові '&f{language}&c'");
        map.put("key_value", "&aМова: &f{language}\n&aКлюч: &f{key}\n&aЗначення: &f{value}");
        map.put("key_set", "&aКлюч '&f{key}&a' встановлено в '&f{value}&a' для мови '&f{language}&a'");
        return map;
    }

    private static Map<String, String> ukrainianReload() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("all_commands", "&aВсі команди перезавантажені!");
        map.put("command", "&aКоманда &f{command} &aперезавантажена!");
        map.put("all_sections", "&aВсі секції перезавантажені!");
        map.put("section", "&aСекція &f{section} &aперезавантажена!");
        map.put("global_settings", "&aГлобальні налаштування перезавантажені!");
        map.put("global_setting", "&aГлобальне налаштування &f{setting} &aперезавантажене!");
        return map;
    }

    private static Map<String, String> ukrainianSystem() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("loaded_language", "Завантажено мову: {language}");
        map.put("failed_load_language", "Не вдалося завантажити мову: {language}");
        map.put("failed_save_messages", "Не вдалося зберегти користувацькі повідомлення для мови: {language}");
        map.put("created_default_config", "Створено конфіг за замовчуванням: {file}");
        map.put("section_not_reloadable", "Секція не перезавантажувана: {section}");
        map.put("command_registered", "Успішно зареєстровано команду: {command} з аліасами: {aliases}");
        map.put("command_usage", "Використання команди: {usage}");
        map.put("subcommand_usages", "Використання підкоманд:");
        map.put("alias_registered", "Успішно зареєстровано аліас: {alias} для команди: {command}");
        map.put("alias_usage", "Використання аліасу: {usage}");
        map.put("generated_permissions", "Згенеровані права для {command}: {permissions}");
        map.put("unregistered_command", "Скасовано реєстрацію команди: {command}");
        return map;
    }

    private static Map<String, String> ukrainianErrors() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        map.put("message_not_set", "Повідомлення повинно бути встановлено перед відправкою");
        map.put("failed_get_commandmap", "Не вдалося отримати CommandMap");
        map.put("registry_not_initialized",
                "CommandRegistry не ініціалізований! Спочатку викличте initialize().");
        map.put("commandmap_not_available", "CommandMap недоступний!");
        map.put("missing_commandinfo", "Клас команди повинен мати анотацію @CommandInfo: {class}");
        map.put("missing_configfile", "Клас {class} повинен мати анотацію @ConfigFile");
        map.put("required_config_missing", "Відсутнє обов'язкове значення конфігу: {path}");
        return map;
    }
}
