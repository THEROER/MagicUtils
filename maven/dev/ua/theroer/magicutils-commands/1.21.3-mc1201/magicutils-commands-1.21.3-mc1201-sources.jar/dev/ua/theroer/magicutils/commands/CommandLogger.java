package dev.ua.theroer.magicutils.commands;

import java.util.function.Supplier;

/**
 * Lightweight logger interface for command engine diagnostics.
 */
public interface CommandLogger {
    /**
     * Logs a debug message.
     *
     * @param message log message
     */
    void debug(String message);

    /**
     * Returns whether debug logging is currently enabled.
     *
     * @return true when debug messages will be emitted
     */
    default boolean isDebugEnabled() {
        return true;
    }

    /**
     * Lazily logs a debug message only when debug output is enabled.
     *
     * @param messageSupplier supplier for the log message
     */
    default void debug(Supplier<String> messageSupplier) {
        if (!isDebugEnabled() || messageSupplier == null) {
            return;
        }
        debug(messageSupplier.get());
    }

    /**
     * Logs an info message.
     *
     * @param message log message
     */
    void info(String message);

    /**
     * Logs a warning message.
     *
     * @param message log message
     */
    void warn(String message);

    /**
     * Logs an error message.
     *
     * @param message log message
     */
    void error(String message);

    /**
     * Logs an error message with an optional exception.
     *
     * @param message log message
     * @param throwable exception to print
     */
    default void error(String message, Throwable throwable) {
        if (throwable == null) {
            error(message);
            return;
        }
        String detail = throwable.getMessage();
        String suffix = (detail != null && !detail.isBlank())
                ? throwable.getClass().getSimpleName() + ": " + detail
                : throwable.getClass().getSimpleName();
        error(message + " (" + suffix + ")");
    }

    /**
     * Returns a no-op logger implementation.
     *
     * @return no-op logger
     */
    static CommandLogger noop() {
        return new CommandLogger() {
            @Override
            public void debug(String message) {
            }

            @Override
            public boolean isDebugEnabled() {
                return false;
            }

            @Override
            public void info(String message) {
            }

            @Override
            public void warn(String message) {
            }

            @Override
            public void error(String message) {
            }
        };
    }
}
