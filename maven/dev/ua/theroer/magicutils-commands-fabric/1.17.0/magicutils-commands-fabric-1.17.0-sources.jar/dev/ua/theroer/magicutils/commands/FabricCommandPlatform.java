package dev.ua.theroer.magicutils.commands;

import dev.ua.theroer.magicutils.platform.Audience;
import dev.ua.theroer.magicutils.platform.fabric.FabricCommandAudience;
import dev.ua.theroer.magicutils.reflect.ReflectiveAccess;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.CommandBlockMinecartEntity;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Method;
import java.util.Locale;

/**
 * Fabric-specific platform hooks for the command engine.
 */
public class FabricCommandPlatform implements CommandPlatform<ServerCommandSource> {
    private final int opLevel;

    /**
     * Creates a platform wrapper using op level 2.
     */
    public FabricCommandPlatform() {
        this(2);
    }

    /**
     * Creates a platform wrapper with a custom op level fallback.
     *
     * @param opLevel op level to use for permission fallback
     */
    public FabricCommandPlatform(int opLevel) {
        this.opLevel = opLevel;
    }

    /**
     * Wraps a Fabric sender into {@link MagicSender}.
     *
     * @param sender Fabric sender
     * @param opLevel op-level fallback for permissions
     * @return wrapped sender or null if unavailable
     */
    public static @Nullable MagicSender wrapMagicSender(ServerCommandSource sender, int opLevel) {
        if (sender == null) {
            return null;
        }
        return new FabricMagicSender(sender, opLevel);
    }

    @Override
    public Class<?> senderType() {
        return ServerCommandSource.class;
    }

    @Override
    public Class<?> playerType() {
        return ServerPlayerEntity.class;
    }

    @Override
    public @Nullable Object getPlayerSender(ServerCommandSource sender) {
        return getPlayerSafe(sender);
    }

    @Override
    public String getName(ServerCommandSource sender) {
        return sender != null ? sender.getName() : "unknown";
    }

    @Override
    public boolean hasPermission(ServerCommandSource sender, String permission, MagicPermissionDefault defaultValue) {
        if (permission == null || permission.isEmpty()) {
            return true;
        }
        if (sender == null) {
            return false;
        }
        return FabricPermissionBridge.check(sender, permission, defaultValue, opLevel);
    }

    @Override
    public void ensurePermissionRegistered(String node, MagicPermissionDefault defaultValue, String description) {
        // No permission registry on Fabric by default.
    }

    @Override
    public Object resolveSenderArgument(ServerCommandSource sender, CommandArgument argument)
            throws SenderMismatchException {
        AllowedSender[] allowed = argument.getAllowedSenders();
        AllowedSender senderKind = classifySender(sender);
        if (!isAllowedSender(allowed, senderKind)) {
            throw new SenderMismatchException(buildSenderError(argument.getType(), allowed));
        }

        Class<?> targetType = argument.getType();
        if (targetType.equals(ServerCommandSource.class)) {
            return sender;
        }
        if (targetType.equals(MagicSender.class)) {
            return new FabricMagicSender(sender, opLevel);
        }
        if (targetType.equals(ServerPlayerEntity.class)) {
            ServerPlayerEntity player = getPlayerSafe(sender);
            if (player != null) {
                return player;
            }
            throw new SenderMismatchException(buildSenderError(argument.getType(), allowed));
        }

        Entity entity = sender != null ? sender.getEntity() : null;
        if (entity != null && targetType.isInstance(entity)) {
            return targetType.cast(entity);
        }

        if (sender != null && targetType.isInstance(sender)) {
            return targetType.cast(sender);
        }

        throw new SenderMismatchException(buildSenderError(argument.getType(), allowed));
    }

    private static final class FabricMagicSender implements MagicSender {
        private final ServerCommandSource sender;
        private final Audience audience;
        private final int opLevel;

        private FabricMagicSender(ServerCommandSource sender, int opLevel) {
            this.sender = sender;
            this.opLevel = opLevel;
            this.audience = new FabricCommandAudience(sender, false);
        }

        @Override
        public Audience audience() {
            return audience;
        }

        @Override
        public String name() {
            return sender != null ? sender.getName() : "unknown";
        }

        @Override
        public boolean hasPermission(String permission) {
            return FabricPermissionBridge.check(sender, permission, opLevel);
        }

        @Override
        public @Nullable String address() {
            if (sender != null && sender.getPlayer() != null
                    && sender.getPlayer().networkHandler != null
                    && sender.getPlayer().networkHandler.getConnectionAddress() != null) {
                return sender.getPlayer().networkHandler.getConnectionAddress().toString()
                        .replace("/", "").split(":")[0];
            }
            return null;
        }

        @Override
        public Object handle() {
            return sender;
        }
    }

    private static final class FabricPermissionBridge {
        private static final String PERMISSIONS_CLASS = "me.lucko.fabric.api.permissions.v0.Permissions";
        private static final Method CHECK_BOOLEAN;
        private static final Method CHECK_INT;
        private static final Method CHECK_SIMPLE;
        private static final Method HAS_PERMISSION_LEVEL;

        static {
            Class<?> permissions = ReflectiveAccess.loadClass(PERMISSIONS_CLASS).orElse(null);
            CHECK_BOOLEAN = permissions != null ? findMethod(permissions, boolean.class) : null;
            CHECK_INT = permissions != null ? findMethod(permissions, int.class) : null;
            CHECK_SIMPLE = permissions != null ? findMethod(permissions, null) : null;
            HAS_PERMISSION_LEVEL = resolvePermissionLevelMethod();
        }

        private FabricPermissionBridge() {
        }

        static boolean check(ServerCommandSource sender, String permission, int opLevel) {
            if (permission == null || permission.isEmpty()) {
                return true;
            }
            if (sender == null) {
                return false;
            }
            Boolean result = tryInvoke(sender, permission, null, opLevel);
            if (result != null) {
                return result;
            }
            return hasPermissionLevel(sender, opLevel);
        }

        static boolean check(ServerCommandSource sender, String permission, MagicPermissionDefault defaultValue,
                             int opLevel) {
            if (permission == null || permission.isEmpty()) {
                return true;
            }
            if (sender == null) {
                return false;
            }
            Boolean result = tryInvoke(sender, permission, defaultValue, opLevel);
            if (result != null) {
                return result;
            }
            return fallback(sender, defaultValue, opLevel);
        }

        private static Boolean tryInvoke(ServerCommandSource sender, String permission,
                                         MagicPermissionDefault defaultValue, int opLevel) {
            if (CHECK_BOOLEAN != null) {
                try {
                    boolean fallback = fallback(sender, defaultValue, opLevel);
                    Object res = ReflectiveAccess.invoke(CHECK_BOOLEAN, null, sender, permission, fallback).orElse(null);
                    return res instanceof Boolean value ? value : null;
                } catch (RuntimeException ignored) {
                }
            }
            if (CHECK_INT != null) {
                try {
                    int fallback = fallbackLevel(defaultValue, opLevel);
                    Object res = ReflectiveAccess.invoke(CHECK_INT, null, sender, permission, fallback).orElse(null);
                    return res instanceof Boolean value ? value : null;
                } catch (RuntimeException ignored) {
                }
            }
            if (CHECK_SIMPLE != null) {
                try {
                    Object res = ReflectiveAccess.invoke(CHECK_SIMPLE, null, sender, permission).orElse(null);
                    return res instanceof Boolean value ? value : null;
                } catch (RuntimeException ignored) {
                }
            }
            return null;
        }

        private static boolean fallback(ServerCommandSource sender, MagicPermissionDefault defaultValue, int opLevel) {
            MagicPermissionDefault effective = defaultValue != null ? defaultValue : MagicPermissionDefault.OP;
            return switch (effective) {
                case TRUE -> true;
                case FALSE -> false;
                case NOT_OP -> !hasPermissionLevel(sender, opLevel);
                case OP -> hasPermissionLevel(sender, opLevel);
            };
        }

        private static int fallbackLevel(MagicPermissionDefault defaultValue, int opLevel) {
            MagicPermissionDefault effective = defaultValue != null ? defaultValue : MagicPermissionDefault.OP;
            return switch (effective) {
                case TRUE -> 0;
                case FALSE -> opLevel + 1;
                case NOT_OP -> 0;
                case OP -> opLevel;
            };
        }

        private static boolean hasPermissionLevel(ServerCommandSource sender, int opLevel) {
            if (sender == null) {
                return false;
            }
            if (HAS_PERMISSION_LEVEL != null) {
                try {
                    Object res = ReflectiveAccess.invoke(HAS_PERMISSION_LEVEL, sender, opLevel).orElse(Boolean.FALSE);
                    return res instanceof Boolean value && value;
                } catch (RuntimeException ignored) {
                }
            }
            return false;
        }

        private static Method findMethod(Class<?> permissionsClass, Class<?> defaultType) {
            for (Method method : permissionsClass.getMethods()) {
                if (!method.getName().equals("check")) {
                    continue;
                }
                Class<?>[] params = method.getParameterTypes();
                if (defaultType == null) {
                    if (params.length == 2 && params[1] == String.class
                            && params[0].isAssignableFrom(ServerCommandSource.class)) {
                        return method;
                    }
                } else {
                    if (params.length == 3 && params[1] == String.class && params[2] == defaultType
                            && params[0].isAssignableFrom(ServerCommandSource.class)) {
                        return method;
                    }
                }
            }
            return null;
        }

        private static Method resolvePermissionLevelMethod() {
            Method direct = ReflectiveAccess.publicMethod(
                    ServerCommandSource.class,
                    "hasPermissionLevel",
                    int.class
            ).orElse(null);
            if (direct != null) {
                return direct;
            }
            Method candidate = null;
            for (Method method : ServerCommandSource.class.getMethods()) {
                if (method.getParameterCount() != 1 || method.getParameterTypes()[0] != int.class) {
                    continue;
                }
                if (method.getReturnType() != boolean.class) {
                    continue;
                }
                if (candidate != null) {
                    return null;
                }
                candidate = method;
            }
            if (candidate != null) {
                candidate.setAccessible(true);
            }
            return candidate;
        }
    }

    private ServerPlayerEntity getPlayerSafe(ServerCommandSource sender) {
        if (sender == null) {
            return null;
        }
        try {
            return sender.getPlayer();
        } catch (Exception ignored) {
            return null;
        }
    }

    private AllowedSender classifySender(ServerCommandSource sender) {
        if (getPlayerSafe(sender) != null) {
            return AllowedSender.PLAYER;
        }

        Entity entity = sender != null ? sender.getEntity() : null;
        if (entity instanceof CommandBlockMinecartEntity) {
            return AllowedSender.MINECART;
        }

        return AllowedSender.CONSOLE;
    }

    @Override
    public AllowedSender inferSenderFromType(Class<?> type) {
        if (type.equals(ServerPlayerEntity.class)) {
            return AllowedSender.PLAYER;
        }
        if (type.equals(CommandBlockMinecartEntity.class)) {
            return AllowedSender.MINECART;
        }
        String name = type.getSimpleName().toLowerCase(Locale.ROOT);
        if (name.contains("commandblock")) {
            return AllowedSender.BLOCK;
        }
        if (name.contains("minecart")) {
            return AllowedSender.MINECART;
        }
        return AllowedSender.ANY;
    }

}
